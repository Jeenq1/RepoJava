/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juegoconmenuinicio;

import graphics.Assets;
import input.KeyBoard;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import state.GameState2;
import state.Menu;

/**
 *
 * @author 3268i
 */
public class Principal extends JFrame implements Runnable{

    public static Dimension TAMVENTANA = new Dimension(500,350);
    private BufferStrategy bs;
    private Graphics g;
    
    private Canvas canvas;
    private Thread thread;
    private KeyBoard keyBoard;
    
    private static boolean running = false;
    public static int NIVEL = 0;
    
    private Menu Menu;
    private GameState2 gamestate2;
    
    public Principal(){
        setTitle("IGR - JUEGO");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setSize(TAMVENTANA);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        
        
        canvas = new Canvas();
        keyBoard = new KeyBoard();
        
        
        canvas.setPreferredSize(TAMVENTANA);
        canvas.setMinimumSize(TAMVENTANA);
        canvas.setMaximumSize(TAMVENTANA);
        
        add(canvas);
        canvas.addKeyListener(keyBoard);
    }
    
    
    
    private void init(){
        Assets.init(); //PREPARAMOS EL MATERIAL A UTILIZAR
        Menu = new Menu();
        gamestate2 = new GameState2();
    }

    private void dibujar(){
        
        bs = canvas.getBufferStrategy();
        if (bs == null) {
            canvas.createBufferStrategy(3);
            return;
        }
        
        g = bs.getDrawGraphics();
        
        g.setColor(Color.white);
        g.fillRect(0, 0, TAMVENTANA.width, TAMVENTANA.height);
        
        
        switch(NIVEL){
            case 0: Menu.draw(g); break;
            case 1: gamestate2.draw(g); break;
        }
        
        g.dispose();
        bs.show();
    }
    
    private void actualizar(){
        keyBoard.update();
        switch(NIVEL){
            case 0: Menu.update(); break;
            case 1: gamestate2.update();break;
        }
    }
    
    private void iniciar(){
        running = true;
        thread = new Thread(this);
        thread.start();
    }
    
    private void parar(){
        try {
            thread.join();
            running = false;
            
        } catch (InterruptedException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.exit(0);
    }
    
    @Override
    public void run() {
        init();
        
        final int NS_POR_SEGUNDO = 1000000000;
        final int APS_OBJETIVO = 60;
        final double NS_POR_ACTUALIZACION = NS_POR_SEGUNDO / APS_OBJETIVO;

        long referenciaActualizacion = System.nanoTime();
        double tiempoTranscurrido;
        double delta = 0;
        requestFocus();
        
        while (running) {
            final long inicioBucle = System.nanoTime();
            tiempoTranscurrido = inicioBucle - referenciaActualizacion;
            referenciaActualizacion = inicioBucle;
            delta += tiempoTranscurrido / NS_POR_ACTUALIZACION;

            while (delta >= 1) {
                actualizar();
                dibujar();
                delta--;
            }
        }
        parar();
    }
    
    public static void main(String[] args) {
        new Principal().iniciar();
    }
}
