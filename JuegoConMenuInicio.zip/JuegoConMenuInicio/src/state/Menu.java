/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package state;

import gameObjects.Boton;
import graphics.Assets;
import input.KeyBoard;
import java.awt.Graphics;
import juegoconmenuinicio.Principal;
import math.Vector2D;

/**
 *
 * @author 3268i
 */
public class Menu {

    private Boton Jugar;
    private Boton Salir;
    
    private int POSICION = 0; //LA POSICION 0 ES SELECCIONANDO JUGAR, Y LA 1 ES SELECCIONANDO SALIR

    public Menu() {
        Jugar = new Boton(new Vector2D(Principal.TAMVENTANA.width/3, Principal.TAMVENTANA.height/6), Assets.jugar1, Assets.jugar2); //JUGAR1 ES LA IMAGEN SIN SELECCIONAR, Y LA OTRA SELECCIONADA
        Salir = new Boton(new Vector2D(Principal.TAMVENTANA.width/3, Principal.TAMVENTANA.height/3), Assets.salir1, Assets.salir2);
    }

    public void update() {
        if (KeyBoard.UP == true && POSICION == 1) { 
            POSICION--; //RECORDAMOS QUE 0(JUGAR) ESTÁ ENCIMA DE 1(SALIR), LO CUAL SUBIR LA POSICION, ES VOLVIENDO A 0, Y PARA BAJAR, PONIENDO LA POSICION EN 1
        } else if (KeyBoard.DOWN == true && POSICION == 0) {
            POSICION++;
        }
        if (KeyBoard.MENU == true && POSICION == 0) {
            Principal.NIVEL = 1;
        } else if (KeyBoard.MENU == true && POSICION == 1) {
            System.exit(0);
        }
    }

    public void draw(Graphics g) {
        if (POSICION == 0) {
            Jugar.draw2(g);
            Salir.draw(g);
        } else {
            Jugar.draw(g);
            Salir.draw2(g);
        }
    }
}
