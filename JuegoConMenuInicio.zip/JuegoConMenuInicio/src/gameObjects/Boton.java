/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameObjects;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import math.Vector2D;

/**
 *
 * @author 3268i
 */
public class Boton extends GameObject{

    static int POSITION = 0;
    
    public Boton(Vector2D position, BufferedImage texture, BufferedImage texture2) {
        super(position, texture, texture2);
    }

    @Override
    public void update() {
        
    }

    @Override
    public void draw(Graphics g) {
        g.drawImage(texture, (int)position.getX(), (int)position.getY(), null); //AQUI USAMOS LA TEXTURA CON LA IMAGEN SIN SELECCIONAR
    }
    
    public void draw2(Graphics g){
        g.drawImage(texture2, (int)position.getX(), (int)position.getY(), null); //AQUI USAMOS LA TEXTURA CON LA IMAGEN SELECCIONADA
    }
    
}
